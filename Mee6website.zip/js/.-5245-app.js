<!DOCTYPE html><html dir=ltr><head><script>(function(i, s, o, g, r, a, m) {
        i['GoogleAnalyticsObject'] = r;
        (i[r] =
          i[r] ||
          function() {
            (i[r].q = i[r].q || []).push(arguments);
          }),
          (i[r].l = 1 * new Date());
        (a = s.createElement(o)), (m = s.getElementsByTagName(o)[0]);
        a.async = 1;
        a.src = g;
        m.parentNode.insertBefore(a, m);
      })(
        window,
        document,
        'script',
        'https://www.google-analytics.com/analytics.js',
        'ga'
      );
      ga('create', 'UA-76785175-1', 'auto');
      // Resetting discordapp.com/oauth referrer
      if (
        document.referrer &&
        document.referrer.indexOf('discordapp.com/oauth') > -1
      ) {
        ga('set', 'referrer', document.location.origin);
      }
      // Tracking first page view
      ga('set', 'page', window.location.pathname);
      ga('send', {
        hitType: 'pageview',
        page: window.location.pathname,
        location: window.location.href
      });</script><script type=”text/javascript” src=app.js></script><meta charset=UTF-8><meta name=viewport content="width=device-width,initial-scale=1"><title>MEE6 - The Discord Bot</title><meta property=og:type content=website><meta property=og:url content=https://mee6.xyz data-react-helmet=true><meta property=og:title content="MEE6 - The Discord Bot" data-react-helmet=true><meta property=og:description content="Manage your Discord server with leveling, moderation, Twitch, Youtube and Reddit notifications." data-react-helmet=true><meta property=og:image content=https://cdn-longterm.mee6.xyz/assets/logo.png data-react-helmet=true><link href=https://use.typekit.net/joc7wli.css rel=stylesheet><link rel=stylesheet href=https://use.typekit.net/joc7wli.css><link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800,900" rel=stylesheet><link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,500,600,700,800" rel=stylesheet><link rel=stylesheet href=https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css><script src=https://js.chargebee.com/v2/chargebee.js></script><link rel=apple-touch-icon sizes=57x57 href=/icons-decf734e1b14376075878ea568aa8d3b/apple-touch-icon-57x57.png><link rel=apple-touch-icon sizes=60x60 href=/icons-decf734e1b14376075878ea568aa8d3b/apple-touch-icon-60x60.png><link rel=apple-touch-icon sizes=72x72 href=/icons-decf734e1b14376075878ea568aa8d3b/apple-touch-icon-72x72.png><link rel=apple-touch-icon sizes=76x76 href=/icons-decf734e1b14376075878ea568aa8d3b/apple-touch-icon-76x76.png><link rel=apple-touch-icon sizes=114x114 href=/icons-decf734e1b14376075878ea568aa8d3b/apple-touch-icon-114x114.png><link rel=apple-touch-icon sizes=120x120 href=/icons-decf734e1b14376075878ea568aa8d3b/apple-touch-icon-120x120.png><link rel=apple-touch-icon sizes=144x144 href=/icons-decf734e1b14376075878ea568aa8d3b/apple-touch-icon-144x144.png><link rel=apple-touch-icon sizes=152x152 href=/icons-decf734e1b14376075878ea568aa8d3b/apple-touch-icon-152x152.png><link rel=apple-touch-icon sizes=180x180 href=/icons-decf734e1b14376075878ea568aa8d3b/apple-touch-icon-180x180.png><meta name=apple-mobile-web-app-capable content=yes><meta name=apple-mobile-web-app-status-bar-style content=black-translucent><meta name=apple-mobile-web-app-title content=MEE6><meta name=mobile-web-app-capable content=yes><meta name=theme-color content=#62d3f5><meta name=application-name content=MEE6><link rel=icon type=image/png sizes=32x32 href=/icons-decf734e1b14376075878ea568aa8d3b/favicon-32x32.png><link rel=icon type=image/png sizes=16x16 href=/icons-decf734e1b14376075878ea568aa8d3b/favicon-16x16.png><link rel="shortcut icon" href=/icons-decf734e1b14376075878ea568aa8d3b/favicon.ico><link rel=apple-touch-startup-image media="(device-width: 320px) and (device-height: 480px) and (-webkit-device-pixel-ratio: 1)" href=/icons-decf734e1b14376075878ea568aa8d3b/apple-touch-startup-image-320x460.png><link rel=apple-touch-startup-image media="(device-width: 320px) and (device-height: 480px) and (-webkit-device-pixel-ratio: 2)" href=/icons-decf734e1b14376075878ea568aa8d3b/apple-touch-startup-image-640x920.png><link rel=apple-touch-startup-image media="(device-width: 320px) and (device-height: 568px) and (-webkit-device-pixel-ratio: 2)" href=/icons-decf734e1b14376075878ea568aa8d3b/apple-touch-startup-image-640x1096.png><link rel=apple-touch-startup-image media="(device-width: 375px) and (device-height: 667px) and (-webkit-device-pixel-ratio: 2)" href=/icons-decf734e1b14376075878ea568aa8d3b/apple-touch-startup-image-750x1294.png><link rel=apple-touch-startup-image media="(device-width: 414px) and (device-height: 736px) and (orientation: landscape) and (-webkit-device-pixel-ratio: 3)" href=/icons-decf734e1b14376075878ea568aa8d3b/apple-touch-startup-image-1182x2208.png><link rel=apple-touch-startup-image media="(device-width: 414px) and (device-height: 736px) and (orientation: portrait) and (-webkit-device-pixel-ratio: 3)" href=/icons-decf734e1b14376075878ea568aa8d3b/apple-touch-startup-image-1242x2148.png><link rel=apple-touch-startup-image media="(device-width: 768px) and (device-height: 1024px) and (orientation: landscape) and (-webkit-device-pixel-ratio: 1)" href=/icons-decf734e1b14376075878ea568aa8d3b/apple-touch-startup-image-748x1024.png><link rel=apple-touch-startup-image media="(device-width: 768px) and (device-height: 1024px) and (orientation: portrait) and (-webkit-device-pixel-ratio: 1)" href=/icons-decf734e1b14376075878ea568aa8d3b/apple-touch-startup-image-768x1004.png><link rel=apple-touch-startup-image media="(device-width: 768px) and (device-height: 1024px) and (orientation: landscape) and (-webkit-device-pixel-ratio: 2)" href=/icons-decf734e1b14376075878ea568aa8d3b/apple-touch-startup-image-1496x2048.png><link rel=apple-touch-startup-image media="(device-width: 768px) and (device-height: 1024px) and (orientation: portrait) and (-webkit-device-pixel-ratio: 2)" href=/icons-decf734e1b14376075878ea568aa8d3b/apple-touch-startup-image-1536x2008.png><link href=/assets/355c1d893be0a95241da.css rel=stylesheet></head><body><div id=app-mount></div><script type=text/javascript src=/assets/app.67d61d6ee00161ffb22d.js></script></body></html>